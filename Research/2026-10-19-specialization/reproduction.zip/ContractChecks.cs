using Tedd.RTree;
internal static class ContractChecks
{
    internal static void Run()
    {
        using var c=new ConcurrentRTree<int>();
        using var c2=new ConcurrentRTree2D<int,int>();
        using var c3=new ConcurrentRTree3D<int,int>();
        IReadOnlySpatialIndex<Rectangle,int>[] original=[new RTree<int>(),new SnapshotRTree<int>(),c];
        IReadOnlySpatialIndex<Rectangle2D<int>,int>[] two=[new RTree2D<int,int>(),new SnapshotRTree2D<int,int>(),c2];
        IReadOnlySpatialIndex<Box<int>,int>[] three=[new RTree3D<int,int>(),new SnapshotRTree3D<int,int>(),c3];
        foreach(var tree in original) Empty(tree,default(Rectangle));
        foreach(var tree in two) Empty(tree,default(Rectangle2D<int>));
        foreach(var tree in three) Empty(tree,default(Box<int>));
        Write(new RTree<int>(),new Rectangle(0,0,1,1));
        Write(new RTree2D<int,int>(),new Rectangle2D<int>(0,0,1,1));
        Write(new RTree3D<int,int>(),new Box<int>(0,0,0,1,1,1));
    }
    private static void Empty<B>(IReadOnlySpatialIndex<B,int> tree,B bounds) where B:struct
    {
        var list=new List<int>{42};int[] counts=[-1];
        if(tree.Count!=0 || tree.Search(bounds,list)!=0 || tree.Search(bounds).Count!=0 ||
            tree.SearchBatch([bounds],[list],counts)!=0 || counts[0]!=0 || list.Count!=1)
            throw new Exception("Read contract mismatch");
    }
    private static void Write<B>(IMutableSpatialIndex<B,int> tree,B bounds) where B:struct
    {
        tree.Insert(bounds,7);
        if(tree.Count!=1 || tree.Search(bounds).Single()!=7 || !tree.Update(bounds,7,bounds) || !tree.Remove(bounds,7))
            throw new Exception("Mutable contract mismatch");
        tree.Insert(bounds,8);tree.Clear();if(tree.Count!=0)throw new Exception("Clear contract mismatch");
    }
}
