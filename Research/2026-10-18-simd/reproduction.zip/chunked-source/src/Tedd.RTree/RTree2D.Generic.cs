using System.Runtime.CompilerServices;
using System.Numerics;

namespace Tedd.RTree;

/// <summary>A mutable two-dimensional R-tree with incremental updates and packed bulk loading.</summary>
/// <remarks>Concurrent searches are safe while the tree is unchanged, provided each search owns its result list. Mutation during a search is not safe.</remarks>
public sealed class RTree2D<TCoordinate, T>
    where TCoordinate : struct, INumber<TCoordinate>
{
    private sealed class Node(bool leaf, int capacity, T[]? packedValues = null, int valueStart = 0)
    {
        // Packed nodes share contiguous values; mutation detaches only the affected leaf.
        internal readonly Rectangle2D<TCoordinate>[] Boxes = new Rectangle2D<TCoordinate>[capacity + 1];
        internal T[]? Values = packedValues ?? (leaf ? new T[capacity + 1] : null);
        internal int ValueStart = valueStart;
        internal int PackedCount;
        internal readonly Node?[]? Children = leaf ? null : new Node?[capacity + 1];
        internal readonly bool Leaf = leaf;
        internal int Count;
        internal Rectangle2D<TCoordinate> Bounds;
    }

    private struct Entry(Rectangle2D<TCoordinate> bounds, Node? child, T value)
    {
        internal Rectangle2D<TCoordinate> Bounds = bounds;
        internal Node? Child = child;
        internal T Value = value;
    }

    // At most capacity + 1 entries; exact integer metrics contain managed BigInteger storage.
    // A bounded inline array keeps this split-local cache off the managed heap.
    [InlineArray(129)]
    private struct SplitAreaBuffer { private SpatialMeasure<TCoordinate> _element0; }

    private readonly int _capacity;
    private readonly int _minimum;
    private Node _root;
    private List<Entry>? _reinsertScratch;

    /// <param name="maxEntries">Maximum entries per node, from 4 to 128.</param>
    public RTree2D(int maxEntries = 16)
    {
        if (maxEntries is < 4 or > 128)
            throw new ArgumentOutOfRangeException(nameof(maxEntries));

        _capacity = maxEntries;
        _minimum = maxEntries / 2;
        _root = new Node(true, maxEntries);
    }

    /// <summary>Number of indexed items.</summary>
    public int Count { get; private set; }

    /// <summary>Inserts an item. Duplicate items and rectangles are permitted.</summary>
    public void Insert(Rectangle2D<TCoordinate> bounds, T item)
    {
        InsertEntry(new Entry(bounds, null, item));
        Count++;
    }

    private void InsertEntry(Entry entry)
    {
        Insert(_root, entry, out Node? sibling);
        if (sibling is not null)
        {
            Node oldRoot = _root;
            Node newRoot = new(false, _capacity);
            Add(newRoot, new Entry(oldRoot.Bounds, oldRoot, default!));
            Add(newRoot, new Entry(sibling.Bounds, sibling, default!));
            _root = newRoot;
        }
    }

    /// <summary>Removes one entry matching both its bounds and value.</summary>
    /// <returns>Whether a matching entry was found.</returns>
    public bool Remove(Rectangle2D<TCoordinate> bounds, T item)
    {
        if (Count == 0 || !_root.Bounds.Contains(bounds)) return false;
        List<Entry> reinserts = _reinsertScratch ??= [];
        try
        {
            if (!Remove(_root, bounds, item, reinserts)) return false;
            Count--;
            while (!_root.Leaf && _root.Count == 1)
                _root = _root.Children![0]!;
            if (_root.Count == 0)
                _root = new Node(true, _capacity);
            foreach (Entry entry in reinserts)
                InsertEntry(entry);
            if (Count == 0) _reinsertScratch = null;
            return true;
        }
        finally { reinserts.Clear(); }
    }

    /// <summary>Moves one matching entry to new bounds.</summary>
    /// <returns>Whether a matching entry was found and moved.</returns>
    public bool Update(Rectangle2D<TCoordinate> oldBounds, T item, Rectangle2D<TCoordinate> newBounds)
    {
        if (!Remove(oldBounds, item)) return false;
        Insert(newBounds, item);
        return true;
    }

    /// <summary>Builds a packed tree from a batch. The tree must be empty; later individual updates are allowed.</summary>
    /// <remarks>Uses Hilbert ordering and bottom-up packing. Input order is not modified.</remarks>
    public void BulkLoad(IReadOnlyList<SpatialEntry2D<TCoordinate, T>> items)
        => BulkLoadCore(items, null);

    /// <summary>Builds a packed tree using caller-owned reusable scratch arrays.</summary>
    /// <remarks>The tree must be empty. Do not use the workspace concurrently with another bulk load.</remarks>
    public void BulkLoad(IReadOnlyList<SpatialEntry2D<TCoordinate, T>> items, BulkLoadWorkspace workspace)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        BulkLoadCore(items, workspace);
    }

    private void BulkLoadCore(IReadOnlyList<SpatialEntry2D<TCoordinate, T>> items, BulkLoadWorkspace? workspace)
    {
        ArgumentNullException.ThrowIfNull(items);
        if (Count != 0)
            throw new InvalidOperationException("Bulk loading requires an empty tree.");
        int itemCount = items.Count;
        if (itemCount == 0)
            return;

        if (items is SpatialEntry2D<TCoordinate, T>[] array)
        {
            BulkLoadPacked(array, workspace);
        }
        else
        {
            // Retain IReadOnlyList's indexed contract, including custom lists without enumeration.
            SpatialEntry2D<TCoordinate, T>[] copy = new SpatialEntry2D<TCoordinate, T>[itemCount];
            for (int i = 0; i < copy.Length; i++) copy[i] = items[i];
            BulkLoadPacked(copy, workspace);
        }
    }

    private void BulkLoadPacked(ReadOnlySpan<SpatialEntry2D<TCoordinate, T>> items, BulkLoadWorkspace? workspace)
    {
        int itemCount = items.Length;
        workspace?.EnsureCapacity(itemCount);
        Span<int> order = workspace is null ? new int[itemCount] : workspace.Order.AsSpan(0, itemCount);
        Span<uint> keys = workspace is null ? new uint[itemCount] : workspace.HilbertKeys(itemCount);
        Rectangle2D<TCoordinate> extent = items[0].Bounds;
        for (int i = 0; i < itemCount; i++) extent = Rectangle2D<TCoordinate>.Union(extent, items[i].Bounds);
        var axisX = new SpatialKeyAxis<TCoordinate>(extent.MinX, extent.MaxX, 65535);
        var axisY = new SpatialKeyAxis<TCoordinate>(extent.MinY, extent.MaxY, 65535);
        for (int i = 0; i < itemCount; i++)
        {
            Rectangle2D<TCoordinate> b = items[i].Bounds;
            keys[i] = HilbertOrder.Encode(axisX.Center(b.MinX, b.MaxX), axisY.Center(b.MinY, b.MaxY));
            order[i] = i;
        }
        // Primitive keys avoid virtual comparisons through an indirect coordinate lookup.
        if (itemCount < 2048)
            keys.Sort(order);
        else
        {
            Span<int> scatter = workspace is null ? new int[itemCount] : workspace.HilbertScatter(itemCount);
            HilbertOrder.SortIndices(keys, order, scatter);
        }
        // Keep ordinary-sized value chunks below 64 KiB of payload. A power
        // of node capacity aligns chunk boundaries with complete packed subtrees.
        int valueLimit = Math.Max(_capacity, 65536 / Unsafe.SizeOf<T>());
        int chunkCapacity = _capacity;
        while (chunkCapacity <= valueLimit / _capacity) chunkCapacity *= _capacity;
        T[] packedValues = Array.Empty<T>();
        int valueStart = 0;
        Node[] level = new Node[(itemCount - 1) / _capacity + 1];
        for (int n = 0, start = 0; n < level.Length; n++, start += _capacity)
        {
            if (valueStart == packedValues.Length)
            {
                packedValues = new T[Math.Min(chunkCapacity, itemCount - start)];
                valueStart = 0;
            }
            Node node = new(true, _capacity, packedValues, valueStart);
            int end = Math.Min(start + _capacity, itemCount);
            for (int i = start; i < end; i++)
            {
                SpatialEntry2D<TCoordinate, T> item = items[order[i]];
                Add(node, new Entry(item.Bounds, null, item.Item));
            }
            valueStart += node.Count;
            node.PackedCount = node.Count;
            level[n] = node;
        }
        while (level.Length > 1)
        {
            Node[] parents = new Node[(level.Length - 1) / _capacity + 1];
            for (int n = 0, start = 0; n < parents.Length; n++, start += _capacity)
            {
                Node parent = new(false, _capacity);
                int end = Math.Min(start + _capacity, level.Length);
                for (int i = start; i < end; i++)
                    Add(parent, new Entry(level[i].Bounds, level[i], default!));
                Node first = level[start], last = level[end - 1];
                // Chunks are consecutive and never reused. Matching endpoints
                // therefore prove that every intervening value has one owner.
                if (first.PackedCount != 0 && ReferenceEquals(first.Values, last.Values))
                {
                    parent.Values = first.Values;
                    parent.ValueStart = first.ValueStart;
                    parent.PackedCount = last.ValueStart + last.PackedCount - parent.ValueStart;
                }
                parents[n] = parent;
            }
            level = parents;
        }
        _root = level[0];
        Count = itemCount;
    }

    /// <summary>Appends intersecting items to <paramref name="results"/> and returns the number appended.</summary>
    public int Search(Rectangle2D<TCoordinate> bounds, List<T> results)
    {
        ArgumentNullException.ThrowIfNull(results);
        if (_root.Count == 0 || !_root.Bounds.Intersects(bounds))
            return 0;
        return _root.PackedCount != 0 && bounds.Contains(_root.Bounds) ? CollectValues(_root, results) : Search(_root, bounds, results);
    }

    /// <summary>Appends matches for each query to its result list and writes the appended counts.</summary>
    /// <returns>The total number of matches appended across all queries.</returns>
    /// <remarks>
    /// Results must have one non-null list per query; counts must have at least one slot per query.
    /// Existing list contents are preserved. Inputs and output storage must not be changed concurrently.
    /// The tree must not be mutated while the batch runs.
    /// </remarks>
    public long SearchBatch(ReadOnlySpan<Rectangle2D<TCoordinate>> queries, ReadOnlySpan<List<T>> results, Span<int> counts)
    {
        if (results.Length != queries.Length)
            throw new ArgumentException("Provide one result list per query.", nameof(results));
        if (counts.Length < queries.Length)
            throw new ArgumentException("Provide at least one count slot per query.", nameof(counts));
        // Validate the entire batch before appending, including lists belonging to empty queries.
        for (int i = 0; i < results.Length; i++)
            if (results[i] is null)
                throw new ArgumentException("Result lists must not be null.", nameof(results));
        long total = 0;
        for (int i = 0; i < queries.Length; i++)
        {
            int found = Search(queries[i], results[i]);
            counts[i] = found;
            total += found;
        }
        return total;
    }

    /// <summary>Returns a new list containing items whose bounds intersect <paramref name="bounds"/>.</summary>
    public List<T> Search(Rectangle2D<TCoordinate> bounds)
    {
        List<T> results = [];
        Search(bounds, results);
        return results;
    }

    /// <summary>Removes all indexed items.</summary>
    public void Clear()
    {
        _root = new Node(true, _capacity);
        Count = 0;
        _reinsertScratch = null;
    }

    private static int CollectValues(Node node, List<T> results)
    {
        if (node.Leaf || node.PackedCount != 0)
        {
            int count = node.Leaf ? node.Count : node.PackedCount;
            results.AddRange(node.Values!.AsSpan(node.ValueStart, count));
            return count;
        }
        int found = 0;
        for (int i = 0; i < node.Count; i++) found += CollectValues(node.Children![i]!, results);
        return found;
    }

    private static int Search(Node node, in Rectangle2D<TCoordinate> bounds, List<T> results)
    {
        // Validate the active prefix once; mutations cannot overlap a search (H-004/H-014).
        ReadOnlySpan<Rectangle2D<TCoordinate>> entries = node.Boxes.AsSpan(0, node.Count);
        int found = 0;
        if (node.Leaf)
        {
            for (int i = 0; i < entries.Length; i++)
            {
                ref readonly Rectangle2D<TCoordinate> entry = ref entries[i];
                if (entry.Intersects(bounds))
                {
                    results.Add(node.Values![node.ValueStart + i]);
                    found++;
                }
            }
        }
        else
        {
            for (int i = 0; i < entries.Length; i++)
            {
                ref readonly Rectangle2D<TCoordinate> entry = ref entries[i];
                if (entry.Intersects(bounds))
                {
                    // Every descendant lies within this entry. Containment therefore permits
                    // collecting values without further geometry tests, preserving duplicates.
                    // Check only intersecting children to limit selective-query overhead (H-013/H-014).
                    found += bounds.Contains(entry)
                        ? CollectValues(node.Children![i]!, results)
                        : Search(node.Children![i]!, bounds, results);
                }
            }
        }
        return found;
    }

    private bool Remove(Node node, in Rectangle2D<TCoordinate> bounds, T item, List<Entry> reinserts)
    {
        if (node.Leaf)
        {
            for (int i = 0; i < node.Count; i++)
            {
                Entry entry = ReadEntry(node, i);
                if (entry.Bounds != bounds || !EqualityComparer<T>.Default.Equals(entry.Value, item)) continue;
                RemoveAt(node, i);
                RecomputeBounds(node);
                return true;
            }
            return false;
        }

        for (int i = 0; i < node.Count; i++)
        {
            if (!node.Boxes[i].Contains(bounds)) continue;
            Node child = node.Children![i]!;
            if (!Remove(child, bounds, item, reinserts)) continue;
            if (node.PackedCount != 0) MakeWritable(node);
            if (child.Count < _minimum)
            {
                CollectLeafEntries(child, reinserts);
                RemoveAt(node, i);
            }
            else
                node.Boxes[i] = child.Bounds;
            RecomputeBounds(node);
            return true;
        }
        return false;
    }

    private static void RemoveAt(Node node, int index)
    {
        if (node.PackedCount != 0) MakeWritable(node);
        int last = --node.Count;
        if (index != last)
        {
            node.Boxes[index] = node.Boxes[last];
            if (node.Leaf) node.Values![index] = node.Values[last];
            else node.Children![index] = node.Children[last];
        }
        node.Boxes[last] = default;
        if (node.Leaf) node.Values![last] = default!;
        else node.Children![last] = null;
    }

    private static void RecomputeBounds(Node node)
    {
        if (node.Count == 0)
        {
            node.Bounds = default;
            return;
        }
        Rectangle2D<TCoordinate> bounds = node.Boxes[0];
        for (int i = 1; i < node.Count; i++)
            bounds = Rectangle2D<TCoordinate>.Union(bounds, node.Boxes[i]);
        node.Bounds = bounds;
    }

    private static void CollectLeafEntries(Node node, List<Entry> entries)
    {
        if (node.Leaf)
        {
            for (int i = 0; i < node.Count; i++) entries.Add(ReadEntry(node, i));
            // This entire subtree is discarded after collecting its entries.
            // Release shared slots even for leaves never individually mutated.
            if (node.PackedCount != 0)
                node.Values!.AsSpan(node.ValueStart, node.Count).Clear();
        }
        else
        {
            for (int i = 0; i < node.Count; i++) CollectLeafEntries(node.Children![i]!, entries);
        }
    }

    private void Insert(Node node, Entry entry, out Node? sibling)
    {
        if (node.PackedCount != 0) MakeWritable(node);
        if (node.Leaf)
        {
            Add(node, entry);
        }
        else
        {
            int selected = ChooseSubtree(node, entry.Bounds);
            Node child = node.Children![selected]!;
            Insert(child, entry, out Node? childSibling);
            node.Boxes[selected] = child.Bounds;
            node.Bounds = Rectangle2D<TCoordinate>.Union(node.Bounds, child.Bounds);
            if (childSibling is not null)
                Add(node, new Entry(childSibling.Bounds, childSibling, default!));
        }

        sibling = node.Count > _capacity ? Split(node) : null;
    }

    private static int ChooseSubtree(Node node, in Rectangle2D<TCoordinate> bounds)
    {
        int best = 0;
        SpatialMeasure<TCoordinate> bestEnlargement = SpatialMeasure<TCoordinate>.PositiveInfinity;
        SpatialMeasure<TCoordinate> bestArea = SpatialMeasure<TCoordinate>.PositiveInfinity;
        for (int i = 0; i < node.Count; i++)
        {
            Rectangle2D<TCoordinate> current = node.Boxes[i];
            SpatialMeasure<TCoordinate> area = current.Area;
            SpatialMeasure<TCoordinate> enlargement = Enlargement(current, bounds, area);
            if (enlargement < bestEnlargement ||
                (enlargement == bestEnlargement && area < bestArea))
            {
                best = i;
                bestEnlargement = enlargement;
                bestArea = area;
            }
        }
        return best;
    }

    private Node Split(Node node)
    {
        int length = node.Count;
        Entry[] entries = new Entry[length];
        SplitAreaBuffer entryAreas = default;
        for (int i = 0; i < length; i++)
        {
            entries[i] = ReadEntry(node, i);
            entryAreas[i] = entries[i].Bounds.Area;
        }
        int seedA = 0, seedB = 1;
        SpatialMeasure<TCoordinate> worstWaste = SpatialMeasure<TCoordinate>.NegativeInfinity;
        for (int i = 0; i < length - 1; i++)
        {
            for (int j = i + 1; j < length; j++)
            {
                SpatialMeasure<TCoordinate> waste = Rectangle2D<TCoordinate>.Union(entries[i].Bounds, entries[j].Bounds).Area -
                    entryAreas[i] - entryAreas[j];
                if (waste > worstWaste)
                {
                    worstWaste = waste;
                    seedA = i;
                    seedB = j;
                }
            }
        }

        Node other = new(node.Leaf, _capacity);
        bool[] assigned = new bool[length];
        Entry first = entries[seedA], second = entries[seedB];
        node.Count = 0;
        Add(node, first);
        Add(other, second);
        assigned[seedA] = assigned[seedB] = true;
        int remaining = length - 2;

        while (remaining > 0)
        {
            if (node.Count + remaining == _minimum || other.Count + remaining == _minimum)
            {
                Node target = node.Count + remaining == _minimum ? node : other;
                for (int i = 0; i < length; i++)
                    if (!assigned[i]) Add(target, entries[i]);
                break;
            }

            int selected = -1;
            SpatialMeasure<TCoordinate> greatestDifference = SpatialMeasure<TCoordinate>.NegativeInfinity;
            SpatialMeasure<TCoordinate> areaA = node.Bounds.Area, areaB = other.Bounds.Area;
            SpatialMeasure<TCoordinate> enlargementA = SpatialMeasure<TCoordinate>.Zero, enlargementB = SpatialMeasure<TCoordinate>.Zero;
            for (int i = 0; i < length; i++)
            {
                if (assigned[i]) continue;
                SpatialMeasure<TCoordinate> a = Enlargement(node.Bounds, entries[i].Bounds, areaA);
                SpatialMeasure<TCoordinate> b = Enlargement(other.Bounds, entries[i].Bounds, areaB);
                SpatialMeasure<TCoordinate> difference = SpatialMeasure<TCoordinate>.Abs(a - b);
                if (difference > greatestDifference)
                {
                    greatestDifference = difference;
                    selected = i;
                    enlargementA = a;
                    enlargementB = b;
                }
            }

            Node destination = enlargementA < enlargementB ? node :
                enlargementB < enlargementA ? other :
                areaA < areaB ? node :
                areaB < areaA ? other :
                node.Count <= other.Count ? node : other;
            Add(destination, entries[selected]);
            assigned[selected] = true;
            remaining--;
        }
        // The vacated slots otherwise retain values and child nodes after a split.
        Array.Clear(node.Boxes, node.Count, length - node.Count);
        if (node.Leaf) Array.Clear(node.Values!, node.Count, length - node.Count);
        else Array.Clear(node.Children!, node.Count, length - node.Count);
        return other;
    }

    private static SpatialMeasure<TCoordinate> Enlargement(in Rectangle2D<TCoordinate> current, in Rectangle2D<TCoordinate> added, SpatialMeasure<TCoordinate> before)
    {
        SpatialMeasure<TCoordinate> after = Rectangle2D<TCoordinate>.Union(current, added).Area;
        return after > before ? after - before : SpatialMeasure<TCoordinate>.Zero;
    }

    private static void MakeWritable(Node node)
    {
        if (node.Leaf)
        {
            T[] values = new T[node.Boxes.Length];
            Span<T> original = node.Values!.AsSpan(node.ValueStart, node.Count);
            original.CopyTo(values);
            // Every ancestor range is invalidated by the mutating path. No live range
            // overlaps this detached leaf; clear its old slots to release references.
            original.Clear();
            node.Values = values;
            node.ValueStart = 0;
        }
        else node.Values = null;
        node.PackedCount = 0;
    }

    private static void Add(Node node, Entry entry)
    {
        int index = node.Count++;
        node.Boxes[index] = entry.Bounds;
        if (node.Leaf) node.Values![node.ValueStart + index] = entry.Value;
        else node.Children![index] = entry.Child;
        node.Bounds = node.Count == 1 ? entry.Bounds : Rectangle2D<TCoordinate>.Union(node.Bounds, entry.Bounds);
    }

    private static Entry ReadEntry(Node node, int index) =>
        new(node.Boxes[index], node.Leaf ? null : node.Children![index], node.Leaf ? node.Values![node.ValueStart + index] : default!);

}
